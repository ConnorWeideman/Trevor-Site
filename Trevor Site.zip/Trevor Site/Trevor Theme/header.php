<!DOCTYPE html>
<!--[if lte IE 6]><html class="preIE7 preIE8 preIE9"><![endif]-->
<!--[if IE 7]><html class="preIE8 preIE9"><![endif]-->
<!--[if IE 8]><html class="preIE9"><![endif]-->
<!--[if gte IE 9]><!-->
<html lang="en">
<!--<![endif]-->

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <title>Superb Property Services</title>

    <meta name="author" content="CM Freelancing">
    <meta name="description" content="Leaders in Cleaning Solutions.">
    <meta name="keywords" content="cleaning, clean, industry, wash, windows, floors, tiles, polish">

    <link rel="icon" href="<?php bloginfo("wpurl")?>/wp-content/uploads/2020/10/small-logo.jpg">

    <script src="https://kit.fontawesome.com/5633037ef4.js" data-auto-replace-svg="nest"></script>

    <?php wp_head()?>

</head>

<body>
    <div id="navbar">
        <header class="design" id="design3" style="display: block">
            <button id="nav-toggle">X</button>
            <nav>
                <div id="image">
                    <img src="<?php bloginfo("wpurl")?>/wp-content/uploads/2020/10/logo.jpg" alt="logo">
                </div>
                <?php wp_nav_menu(array(
                "menu" => "Primary Menu",
                "container" => False,
                "items_wrap" => '<ol id="%1$s" class="%2$s">%3$s</ol>'
            ));?>
            </nav>
            <?php if(is_front_page()):
                $slider = get_field("slider");
                $slide1 = $slider["slide_1"];
                $slide2 = $slider["slide_2"];
                $slide3 = $slider["slide_3"];
                $slide4 = $slider["slide_4"];
                ?>
            <div id="header">
                <div id="wrap">
                    <div class="slide">
                        <img src='<?php echo($slide1["image"])?>'>
                        <div class="info">
                            <h1><?php echo($slide1['text'])?></h1>
                            <div class="background"></div>
                        </div>
                    </div>
                    <div class="slide">
                        <img src='<?php echo($slide2["image"])?>'>
                        <div class="info">
                            <h1><?php echo($slide2['text'])?></h1>
                            <div class="background"></div>
                        </div>
                    </div>
                    <div class="slide">
                        <img src='<?php echo($slide3["image"])?>'>
                        <div class="info">
                            <h1><?php echo($slide3['text'])?></h1>
                            <div class="background"></div>
                        </div>
                    </div>
                    <div class="slide">
                        <img src='<?php echo($slide4["image"])?>'>
                        <div class="info">
                            <h1><?php echo($slide4['text'])?></h1>
                            <div class="background"></div>
                        </div>
                    </div>
                </div>
                <div id="left-right">
                    <div id="left">
                        <i class="fas fa-chevron-left"></i>
                    </div>
                    <div id="right">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
                <div id="header-controls">
                    <input checked type="radio" id="-1">
                    <input type="radio" id="0">
                    <input type="radio" id="1">
                    <input type="radio" id="2">
                </div>
            </div>
            
            <?php else:?>

            <div id="page-header">
            
               <?php the_post_thumbnail()?>
                <div class="info">
                    <h1><?php the_title()?></h1>
                    <div class="background"></div>
                </div>

            </div>

            <?php endif?>
        </header>
    </div>