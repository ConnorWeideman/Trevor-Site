const slider = document.querySelector("#navbar #design3 #header #wrap");
const buttons = document.querySelectorAll("#navbar #design3 #header #header-controls input");
let left = 0;
let id;

function slide() {
    console.log("slide");
    if (left == 3) {
        left = -1;
    }
    else if (left == -2) {
        left = 2
    }
    window.requestAnimationFrame(() => {
        slider.style.left = "-" + (left * 100) + "%";
    });
    left += 1;
    for (let i = 0; i < buttons.length; i++) {
        buttons[i].checked = false;
        if (left == i) {
            buttons[i].checked = true;
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    id = window.setInterval(slide, 5000);
});

buttons.forEach(button => {
    button.addEventListener("click", () => {
        window.clearInterval(id);
        left = parseInt(button.id);
        slide();
        id = window.setInterval(slide, 5000);
    });
});

document.querySelector("#navbar #design3 #header #left-right #left").addEventListener("click", () => {
    window.clearInterval(id);
    left -= 2;
    slide();
    id = window.setInterval(slide, 5000);
});

document.querySelector("#navbar #design3 #header #left-right #right").addEventListener("click", () => {
    window.clearInterval(id);
    slide();
    id = window.setInterval(slide, 5000);
});