document.querySelectorAll(".product").forEach(product => {
    let isOpen = false;
    let h2 = product.querySelector("h2");
    let img = product.querySelector(".img");
    let content = product.querySelector(".content");

    product.addEventListener("click", () => {

        product.style.transition = "0s";
        window.setTimeout(() => { product.style.transition = "0.5s"; }, 500);

        if (isOpen) {
            img.style = "";
            content.style = "";
            h2.style = "";

            product.style.display = "";
            product.style.width = "";
            product.style.height = "";
        }
        else {
            img.style.display = "block";
            content.style.display = "block";
            h2.style.textAlign = "left";

            product.style.display = "block";
            product.style.width = "100%";
            product.style.height = "auto";
            
        }

        isOpen = !isOpen;

    });
});