<footer>
    <section class="design">
        <div id="design3">
            <div class="column">
                <i class="fas fa-phone"></i>
                <a href='tel:<?php echo get_field("phone")?>'>
                    <p><?php echo get_field("phone")?></p>
                </a>
            </div>
            <div class="column">
                <i class="fab fa-facebook"></i>
                <a href='<?php echo get_field("facebook")?>'>
                    <p>Facebook</p>
                </a>
            </div>
            <div class="column">
                <i class="fas fa-envelope"></i>
                <a href="mailto:<?php echo get_field('email')?>">
                    <p><?php echo get_field("email")?></p>
                </a>
            </div>
        </div>
    </section>
</footer>
</body>
<?php wp_footer()?>