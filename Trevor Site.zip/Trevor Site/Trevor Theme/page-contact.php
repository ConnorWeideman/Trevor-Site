<?php get_header();
if(isset($_POST['email'])) {
    $emailContent = "New form submission from: " . htmlspecialchars($_POST['email']) . ".\n Content: \n" . htmlspecialchars($_POST['message']);
    wp_mail("trevorminns@icloud.com", "Form Submission On Website", $emailContent);
}
?>
<main>
    <section id="contact1" class="design">
        <div id="box">
            <div id="left">
                <form action="" method="post">
                    <label for="email">Your Email:</label>
                    <input type="email" name="email" id="email" placeholder="Email..." required>
                    <label for="message">Message:</label>
                    <textarea id="message" name="message" placeholder="Message..." required></textarea>
                    <input id="submit" type="submit">

                    <?php if(isset($_POST['email'])):?>
                        <p id="submitted">Thank you for your submission.</p>
                    <?php endif;?>

                </form>
            </div>
            <div id="right">
                <a href="tel:<?php echo get_field('phone')?>" class="contact">
                    <div class="details"><?php echo get_field("phone")?></div>
                    <i class="fas fa-phone"></i>
                </a>
                <a href='mailto:<?php echo get_field("email")?>' class="contact">
                    <div class="details"><?php echo get_field("email")?></div>
                    <i class="fas fa-envelope"></i>
                </a>
                <a href='<?php echo get_field("facebook")?>' class="contact">
                    <div class="details">Facebook</div>
                    <i class="fab fa-facebook"></i>
                </a>
            </div>
        </div>
    </section>
</main>
<?php get_footer()?>