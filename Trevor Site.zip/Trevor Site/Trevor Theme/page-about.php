<?php get_header()?>
<main>
   
	<?php $mission = get_field("mission")?>
	<section id="mission">

		<h2><?php echo($mission['title'])?></h2>
		<div id="content"><?php echo($mission['content'])?></div>

	</section>

	<?php $history = get_field("history")?>
	<section id="history">
	
		<h2><?php echo($history['title'])?></h2>
		<div id="content"><?php echo($history['content'])?></div>
	
	</section>

</main>
<?php get_footer()?>