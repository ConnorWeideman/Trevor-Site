<?php get_header()?>
<main>
    <section id="products1" class="design">

        <div id="product-row">

            <?php $services = get_field("services");
        foreach ($services as $service):
            if ($service['name']):
        ?>

            <div class="product">
                <div class="img">
                    <img src="<?php echo($service['image'])?>">
                </div>
                <h2><?php echo($service['name'])?></h2>
                <div class="content">
                    <?php echo($service['content'])?>
                </div>
            </div>


            <?php endif; endforeach?>

        </div>
    </section>
</main>
<?php get_footer()?>