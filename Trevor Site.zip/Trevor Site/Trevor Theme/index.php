<?php get_header()?>
<h1 style="text-align: center; max-width: 100%; padding: 50px">The page you are looking for does not exist. Please
    select a page from the navbar.</h1>
<?php get_footer()?>