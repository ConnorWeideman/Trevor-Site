<?php get_header()?>

<main>
    <section class="design" id="main3">
        <section id="about">
            <?php $about = get_field("about")?>

            <h2><?php echo($about['title'])?></h2>
            <p><?php echo($about['content'])?></p>
   
        </section>
        <section id="products">
            <?php $products = get_field("products");?>

            <h2><?php echo($products['title'])?></h2>
            <div id="row">

                <?php foreach ($products as $name => $product):
                if ($name != "title" && $product['name']):?>

                <div class="box">
                    <a href="<?php bloginfo('wpurl')?>/services">
                        <div class="front">
                            <p><?php echo($product['name'])?></p>
                        </div>
                        <div class="back">
                            <img src="<?php echo($product['image'])?>">
                        </div>
                    </a>
                </div>

                <?php endif; endforeach;?>

            </div>
        </section>
    </section>
</main>

<?php get_footer()?>